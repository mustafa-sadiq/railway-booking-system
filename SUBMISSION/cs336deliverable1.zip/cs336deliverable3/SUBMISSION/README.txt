EC2 URL
http://ec2-15-222-65-117.ca-central-1.compute.amazonaws.com:8080/cs336deliverable3/

EC2 TOMCAT CREDENTIALS
username: cs336group30
password: cs336group30

CREDIT APPORTION:
Everyone contributed equally

ADMIN CREDENTIALS:
username: admin
password: admin
